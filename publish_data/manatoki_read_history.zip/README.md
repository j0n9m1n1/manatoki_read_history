# manatoki_read_history for Chrome extension
본 만화 타이틀, 에피소드 저장
- 뷰 페이지 진입 시

이미 봤던 만화의 타이틀 및 에피소드 저장
- 목록 페이지 진입 시
- 시청 시각은 1970-01-01 00:00:00 으로
